#!/bin/bash

# Start docker
start-docker.sh

# Execute specified command
"$@"
